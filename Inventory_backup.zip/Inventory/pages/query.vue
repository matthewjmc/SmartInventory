
<template>

    
</template>

<script>
    export default {
        head(){
            return{
            title: 'Tracking',
            meta: [
                { hid: 'description',
                name: 'description',   
                content: 'Inventory System'
                }
            ]
            }
        }
    }
</script>

<style>

</style>


