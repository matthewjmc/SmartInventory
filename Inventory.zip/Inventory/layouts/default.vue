<template>
  <nuxt />
</template>

<script>

export default {
}

</script>

<style>
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  position: relative;
}

body {
 font-family: Arial, Helvetica, sans-serif;
 font-size: 1rem;
 line-height: 1;
 background: #fbeed4;
}

a {
  color: #666;
  text-decoration: none;
}
ul{
  list-style: none;
}

.page {
  position: center;
  width: inherit;
}


</style>