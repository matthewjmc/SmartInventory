
<template>
  <div class="inv">
    <nuxt-link :to="'login_history/'+userID">
      <v-btn color="#D77113"
        ><img src="~assets/userIcon.png"
      /></v-btn>
    </nuxt-link>
    <div class="loginHist_userId">{{ userID }}</div>
    <div class="loginHist_userFullname">{{ FullName }}</div>
    <div class="loginHist_loggedInTime">{{ TimeLogin }}</div>
  </div>
</template>

<script>
export default {
  name: "loginHist",
  props: ["userID", "TimeLogin", "FullName"]
};
</script>

<style>
.inv {
  font-size: 25px;
  color: #000;
  width: 100%;
  display: flex;
  flex-direction: row;
  background-color: #d77113;
  color: #fff;
  padding-top: 0.25rem;
  padding-bottom: 0.25rem;
  justify-content: left;
  text-align: left;
}


img {
  width: 2rem;
}
button {
  padding-left: 0.8rem;
  padding-right: 0.8rem;
}
</style>
